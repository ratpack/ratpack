images_path = "assets/images"
fonts_path = "assets/stylesheets/fonts"

relative_assets = false
# http_path = "/"
http_images_path = "./"
http_fonts_path = "./fonts"
# add_import_path = "../ratpack-stylesheets"
